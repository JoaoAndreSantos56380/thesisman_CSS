package pt.ul.fc.di.css.javafxexample.presentation.control;

public class MainControllerSingleton {
    public static MainController mainController;   
    public static long user_id; 
    public static String username;
}
