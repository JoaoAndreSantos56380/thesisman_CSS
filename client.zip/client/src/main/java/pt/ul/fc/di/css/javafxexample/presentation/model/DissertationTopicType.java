package pt.ul.fc.di.css.javafxexample.presentation.model;

public enum DissertationTopicType {
    PROJECT,
    DISSERTATION
}
